gnrtv.cells
v.nano


1____Install purr-data in your OS. Here there are the repositories :
https://github.com/agraef/purr-data/releases


2____Once installed check if your Sound Card is working : go to menu media > 'test audio and midi'
and select the 80 value in the Test Tones area. This should emit a sinusoid of 440hz which
corresponds to the note (La / A4).


3____gnrtv.cells is a toolkit to easily design sonic generative algoryhtms with pd, which will require
all folders of the toolkit arranged in the same level. Those directories/folders are:
CODE open gnrtv.cells.nano.pd which is the main template. Save it in the same folder or create nother one for ex.’projects’ in the same level of the rest of folders, otherwise several function will not work.
EXAMPLES a bunch of tiny examples of generative sonic design.
RECS all live sets can be recorded with the start.rec / stop.rec buttons that appears in the bottom section of the Core’s Rack (block which contains FX, signal sends and main clock). 
Those recordings used with Core will be stored in this folder.
SND a couple of samples in .wav in case you want to try samplers (cells is mainly a generative synth tool). Remember to use samples in .wav or .aiff with 16bits


4____Before start, In order to understand how 'cells' works click tuto in the top of the GUI’s template.





////////
N·Joy Sonic Generative Algorythms ^_^



_____note:gnrtv.cells is mainly compatible with Pd vanilla but maybe some element is not compatible. Report in case you find some not supported feature.


///gnrtv.cells 24 by Xa.Manzanares @xamanza  // GNU·GPLv3 2024 X.Manzanares
///// comments suggestions and sonic instruments build orders > IG & Github @xamanza
telegram DM > https://telegram.me/XaviMdAAX




